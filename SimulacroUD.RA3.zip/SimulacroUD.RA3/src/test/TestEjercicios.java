package test;

import java.util.List;

import ejercicios.Ejercicios;

public class TestEjercicios {
	public static void main(String[] args) {
		//1
		System.out.println(Ejercicios.precioEntrada(10, "MARTES", true));
	
		Ejercicios.dibujarZ(5);
		//3
		System.out.println(Ejercicios.sumaPrimerosEspeciales(3, 15, 3));
		System.out.println(Ejercicios.factorialConSaltos(7, 2));
		//4
		System.out.println(Ejercicios.contarPicos(List.of(2, 5, 1, 6, 3, 9, 7),3));
		//5
}
}
