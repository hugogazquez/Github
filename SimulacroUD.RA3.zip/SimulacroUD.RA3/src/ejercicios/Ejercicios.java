package ejercicios;


import java.util.List;

import utiles.Utiles;

public class Ejercicios {
	//1
	public static Integer precioEntrada(Integer edad, String dia, Boolean socio) {
		Integer precioBase=0;
		switch (dia) {
		case "LUNES":
		case "MARTES":
		case "MIERCOLES":
		case "JUEVES":	
			precioBase=8;
		case "VIERNES":
		case "SABADO":
		case "DOMINGO":
			precioBase=12;
			break;
		default:
			return -1;
		}
		if (edad<0) {
			return -1;
		}
		Integer descuento=socio?2:0;
		if (edad <12 || edad >65) {
			descuento+=3;
		}
		return precioBase-descuento;
		
	}

//2
	public static void dibujarZ(Integer lado) {
		for (int i = 0; i < lado; i++) {
			for (int j = 0; j <lado; j++) {
				if (i==0 || i==lado-1 || i + j ==lado-1) {
					System.out.print("*");
				}else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}
	
	//3
	public static Integer sumaPrimerosEspeciales(Integer inicio, Integer fin, Integer cantidad) {
		Integer res = 0;
		Integer contador=0;
		for (int i = inicio; i < fin; i++) {
			if (Utiles.esPrimo(i) || Utiles.esPerfecto(i)) {
				res+=i;
				contador++;
				if (contador>=cantidad) {
					break;
				}
			}
		}
		
		return res;
	}

	//4	
	public static Integer factorialConSaltos(Integer numero, Integer salto) {
		Integer res=1;
    	if (numero==1) {
    		res=1;
    	}else {
    		res=numero*factorialConSaltos(numero-salto, salto);
    	}
    	return res;
		}


	//5
	public static Integer contarPicos(List<Integer> alturas, Integer diferenciaMinima) {
		// contarPicos(LIST.2, 5, 1, 6, 3, 9, 7), 2) -> 3
		Integer contador=0;
		 for (int i = 1; i < alturas.size()-1; i++) {
			Integer e = alturas.get(i);
			Integer antes = alturas.get(i-1);
			Integer despues = alturas.get(i+1);
			if (e>antes && e>despues && (e-antes)>=diferenciaMinima) {
				contador++;
			}
 		}
		 
		 return contador;
		 
	}
}
	//6
